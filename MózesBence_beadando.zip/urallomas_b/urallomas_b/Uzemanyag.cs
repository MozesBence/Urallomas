﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urallomas_b
{
    internal class Uzemanyag : UrbazisElem
    {
        public static int uzemanyagok;
        public override void ToString()
        {
            Console.BackgroundColor = ConsoleColor.Yellow;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("F ");
        }
    }
}
