﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urallomas_b
{
    internal class Urhajos:UrbazisElem
    {
        public int elet = 100;
        public int X { get; set; }
        public int Y { get; set; }

        //public string[,] terkep = new string[22, 22];
        //public void terkepAtir(int x, int y, string item)
        //{
        //    terkep[x, y] = item;
        //}

        //public void terkepFeltolt()
        //{
        //    for(int i = 0; i < terkep.GetLength(0); i++)
        //    {
        //        for(int j = 0; j < terkep.GetLength(1); j++)
        //        {
        //            terkep[i, j] = "X";
        //        }
        //    }
        //}
        public Urhajos(int x, int y)
        {
            X = x;
            Y = y;
        }
        public int getX()
        {
            return X;
        }
        public int getY()
        {
            return Y;
        }

        public int urhajosHarcol()
        {
            Random r = new Random();
            return r.Next(10,34);
        }
        public int getElet()
        {
            return elet;
        }
        public string urhajosElet()
        {
            return ""+elet;
        }
        public override void ToString()
        {

            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("U ");
        }
    }
}
