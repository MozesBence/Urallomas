﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urallomas_b
{
    class Program
    {
        static void Main(string[] args)
        {
            Urbazis u = new Urbazis();
            //u.tablaGeneral();
            //Console.WriteLine(u.ToString());
            u.ToString();
            u.fut();
            Console.ReadLine();
        }
    }
}
