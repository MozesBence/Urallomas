﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urallomas_b
{
    internal class SzuperAlien : UrbazisElem
    {
        public int elet = 100;
        public int alienHarcol()
        {
            Random r = new Random();
            return r.Next(25, 40);
        }
        public override void ToString()
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Write("S ");
        }
    }
}
