﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urallomas_b
{
    internal class Robot : UrbazisElem
    {
        public static int robotokszama;
        public int elet = 100;
        
        public int robotHarcol()
        {
            Random r = new Random();
            return r.Next(10,18);
        }
        public void robotszamNovel()
        {
            robotokszama++;
        }
        public override void ToString()
        {
            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("R ");
        }
        public string robotCounter()
        {
            return "Robotok száma 4/ "+robotokszama;
        }
    }
}
