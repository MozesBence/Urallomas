﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace urallomas_b
{
    internal class Urbazis : UrbazisElem
    {
        //+1 
        public UrbazisElem[,] tabla = new UrbazisElem[22, 22];
        private Urhajos urhajos;

        public string[,] terkep = new string[22, 22];
        public void fut()
        {
            terkepFeltolt();
            kezdoAllas();
            //terkepKiir();
            //urhajosMozog();
            //terkepKiir();
            BFS();
            //terkepKiir();
        }
        public void BFS()
        {
            int n = tabla.GetLength(0);
            int m = tabla.GetLength(1);
            bool[,] visited = new bool[n, m];

            Queue<(int, int)> queue = new Queue<(int, int)>();
            queue.Enqueue((urhajos.getX(), urhajos.getY()));

            while (queue.Count > 0)
            {
                var (x, y) = queue.Dequeue();

                if (x < 0 || y < 0 || x >= n || y >= m || visited[x, y]) continue;

                if (tabla[x, y] is Akadaly || tabla[x, y] is SzuperAlien || tabla[x, y] is Robot) continue;

                //Robot találkozás kezelése
                //if (tabla[x, y] is Robot)
                //{
                //    urhajos.urhajosHarcol();
                    
                //    if (!harcSikeres)
                //    {
                //        Console.WriteLine("Az űrhajós elvesztette a harcot és nem tud továbbhaladni.");
                //        break;
                //    }
                //    else
                //    {
                //        Robot.robotokszama--;
                //    }
                //}

                // Uzemanyag találkozás kezelése
                if (tabla[x, y] is Uzemanyag)
                {
                    Uzemanyag.uzemanyagok++;
                }

                visited[x, y] = true;
                terkepAtir(x, y, " ");  // Bejárt mezőt jelöljük, de nem írjuk felül az eredeti térképet




                Console.Clear();  // Clear előtt ki van rajzolva a teljes tábla
                terkepKiir();
                Console.WriteLine("Űrhajós élete: "+urhajos.getElet());
                Console.WriteLine("Üzemanyagkannák: 3/"+Uzemanyag.uzemanyagok);
                Console.WriteLine("Robotok: 4/"+Robot.robotokszama);
                System.Threading.Thread.Sleep(100);
                queue.Enqueue((x - 1, y));  // Fel
                queue.Enqueue((x + 1, y));  // Le
                queue.Enqueue((x, y - 1));  // Balra
                queue.Enqueue((x, y + 1));  // Jobbra
            }
        }

        public void terkepFeltolt()
        {
            for(int i = 0; i < terkep.GetLength(0); i++)
            {
                for(int j = 0; j < terkep.GetLength(1); j++)
                {
                    terkep[i, j] = "X";
                }
            }
        }
        public void terkepAtir(int x, int y, string item)
        {
            terkep[x, y] = item;
        }
        public int urhajosFel()
        {
            return urhajos.getX() + 1;
        }
        public void kezdoAllas()
        {
            int x = urhajos.getX();
            int y = urhajos.getY();
            terkepAtir(x, y, "U");
        }
        public void terkepKiir()
        {
            for (int i = 0; i < terkep.GetLength(0); i++)
            {
                for (int j = 0; j < terkep.GetLength(1); j++)
                {
                    Console.Write(terkep[i, j]+" ");
                }
                Console.WriteLine(); 
            }
        }

        public void tablaGeneral()
        {
            karaktereketPalyara();
            groundFeltolt();
        }
        public void groundFeltolt()
        {
            for (int i = 0; i < tabla.GetLength(0); i++)
            {
                for (int j = 0; j < tabla.GetLength(1); j++)
                {
                    if (tabla[i, j] == null)
                    {
                        tabla[i, j] = new Ground();
                    }
                }
            }
        }
        public void karaktereketPalyara()
        {
            Random r = new Random();
            akadalyLe(r.Next(25, 50));
            kapuSzelere();
            urhajostLe();
            csokikatLe(4);
            robotokatLe(4);
            szuperalientLe();
            uzemanyagLe(3);
        }

        public void akadalyLe(int db)
        {
            Random r = new Random();
            for (int i = 0; i < db; i++)
            {
                int x, y;
                do
                {
                    x = r.Next(0, 22);
                    y = r.Next(0, 22);
                } while (tabla[x, y] != null);

                tabla[x, y] = new Akadaly();
            }
        }

        public void uzemanyagLe(int db)
        {
            Random r = new Random();
            for (int i = 0; i < db; i++)
            {
                int x, y;
                do
                {
                    x = r.Next(0, 22);
                    y = r.Next(0, 22);
                } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));

                tabla[x, y] = new Uzemanyag();
            }
        }
        public void szuperalientLe()
        {
            Random r = new Random();
            int x, y;
            do
            {
                x = r.Next(0, 22);
                y = r.Next(0, 22);
            } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));

            tabla[x, y] = new SzuperAlien();
        }
        public void robotokatLe(int db)
        {
            Random r = new Random();
            for (int i = 0; i < db; i++)
            {
                int x, y;
                do
                {
                    x = r.Next(0, 22);
                    y = r.Next(0, 22);
                } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));

                tabla[x, y] = new Robot();
                Robot.robotokszama++;
            }
        }
        public void csokikatLe(int db)
        {
            Random r = new Random();
            for (int i = 0; i < db; i++)
            {
                int x, y;
                do
                {
                    x = r.Next(0, 22);
                    y = r.Next(0, 22);
                } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));

                tabla[x, y] = new Csoki();
            }
        }
        public void urhajostLe()
        {
            Random r = new Random();
            int x, y;
            do
            {
                x = r.Next(0, 22);
                y = r.Next(0, 22);
            } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));
            urhajos = new Urhajos(x,y);
            tabla[x, y] = urhajos;
        }

        public bool szomszedokatEllenoriz(int x, int y)
        {
            int max = 22;
            // szomszedos mezok ellenorzese
            bool akadalyFel = (x > 0 && tabla[x - 1, y] is Akadaly);  // Felette
            bool akadalyLe = (x < max - 1 && tabla[x + 1, y] is Akadaly);  // Alatta
            bool akadalyJobbra = (y < max - 1 && tabla[x, y + 1] is Akadaly);  // Jobbra
            bool akadalyBalra = (y > 0 && tabla[x, y - 1] is Akadaly);  // Balra

            int szomszedokSzama = 0;
            if (x > 0) szomszedokSzama++;  // Van felette
            if (x < max - 1) szomszedokSzama++;  // Van alatta
            if (y > 0) szomszedokSzama++;  // Van balra
            if (y < max - 1) szomszedokSzama++;  // Van jobbra

            // Sarok, szel és belso mezok kezelese
            if (szomszedokSzama == 4)
            {
                return !(akadalyFel && akadalyLe && akadalyJobbra && akadalyBalra);
            }
            else if (szomszedokSzama == 3)
            {
                return !(akadalyFel && akadalyLe && akadalyJobbra) &&
                       !(akadalyFel && akadalyLe && akadalyBalra) &&
                       !(akadalyFel && akadalyJobbra && akadalyBalra) &&
                       !(akadalyLe && akadalyJobbra && akadalyBalra);
            }
            else if (szomszedokSzama == 2)
            {
                if (x == 0 && y == 0)
                {
                    return !(akadalyLe && akadalyJobbra);
                }
                else if (x == 0 && y == 21)
                {
                    return !(akadalyLe && akadalyBalra);
                }
                else if (x == 21 && y == 0)
                {
                    return !(akadalyFel && akadalyJobbra);
                }
                else if (x == 21 && y == 21)
                {
                    return !(akadalyFel && akadalyBalra);
                }
            }
            // Ha nincs szomszéd, akkor igaz
            return true;
        }
        public void kapuSzelere()
        {
            Random r = new Random();
            int x, y;
            do
            {
                int tengely = r.Next(0, 2);
                if (tengely == 0)
                {
                    x = r.Next(0, 2) == 0 ? 0 : 21;
                    y = r.Next(0, 22);
                }
                else
                {
                    x = r.Next(0, 22);
                    y = r.Next(0, 2) == 0 ? 0 : 21;
                }
            } while (tabla[x, y] != null || !szomszedokatEllenoriz(x, y));
            tabla[x, y] = new Kapu();
        }
        public override void ToString()
        {
            tablaGeneral();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < tabla.GetLength(0); i++)
            {
                for (int j = 0; j < tabla.GetLength(1); j++)
                {
                    tabla[i, j].ToString();         
                }
                Console.WriteLine();
            }
            Console.ResetColor();
        }
    }
}
